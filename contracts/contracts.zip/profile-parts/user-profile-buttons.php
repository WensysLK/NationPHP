<div class="btn-group">
								<button type="button" class="btn btn-primary">Settings</button>
								<button type="button" class="btn btn-primary bg-split-primary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown">	<span class="visually-hidden">Toggle Dropdown</span>
								</button>
								<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-left">
								<a class="dropdown-item" type="button" href="javascript:;" data-bs-toggle="modal" data-bs-target="#visastamping">Visa Stamping</a>	
									<!--<a class="dropdown-item" href="javascript:;">Interview</a>
                                    <a class="dropdown-item" type="button" href="javascript:;" data-bs-toggle="modal" data-bs-target="#medicalpopup">Medical</a>
									<a class="dropdown-item" type="button" href="javascript:;" data-bs-toggle="modal" data-bs-target="#addEnjaz">Enjaz</a>
                                    <a class="dropdown-item" href="javascript:;">Muzaned</a>
                                    <a class="dropdown-item" href="javascript:;">Finger Print</a>-->
									<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Suspend Account</a>
								</div>
							</div>